<?php
namespace Braintree\Exception;

use Braintree\Exception;

class InvalidChallenge extends Exception
{
}
class_alias('Braintree\Exception\InvalidChallenge', 'Braintree_Exception_InvalidChallenge');
